export interface IPerson {
    Person: {
        firstName: string,
        lastName: string
    };
}
